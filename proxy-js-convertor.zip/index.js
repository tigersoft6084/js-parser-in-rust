const acorn = require("acorn");
const acornTreeWalk = require("acorn-walk");
const acornLoose = require("acorn-loose");
const fs = require('fs');
const path = require('path');
const escodegen = require("escodegen");

const thisHelper = {
    LOCATION_STR: "location",
    MCOP_LOCATION_STR: "__mcopLocation"
}

const generateCodeFromTree = function (jsCodeTree, options = { compact: 'auto', comments: true }) {
    return escodegen.generate(jsCodeTree, options);
};


const findAllOccurrences = function (subject, str) {
    const occurrences = [];
    if (typeof subject !== 'string' || typeof str !== 'string') return Array.from(occurrences);
    let previousIndex = str.indexOf(subject);
    while (previousIndex !== -1) {
        if (occurrences.length > 0) {
            previousIndex = str.indexOf(subject, previousIndex + 1);
        }

        if (previousIndex !== -1) {
            occurrences.push({ index: previousIndex });
        }
    }

    return Array.from(occurrences);
}

const replaceLocationInJsCode = function (jsCode) {
    const MCO_TEMP_TOKEN = 'MCO_TEMP_TOKEN';
    const ALLOWED_CHARS_REGEXP = /[.=\s,;():?\[\]+\-{}&|!>\n\r]/;
    const skippedStrings = Array.from([]);
    const processedPropertyNodeSnippets = Array.from([]);
    const processedMemberNodesDetails = Array.from([]);
    const groupedNodes = {
        literal: Array.from([]),
        memberExpr: Array.from([]),
        identifier: Array.from([]),
        property: Array.from([]),
        objectPattern: Array.from([]),
        allOrdered: Array.from([]),
    };

    if (typeof jsCode !== 'string')
        throw new Error('Invalid JavaScript code');

    if (! /location/mg.test(jsCode))
        return jsCode;

    const looksLikeURL = (str) => {
        const matches = (str + '').match(/\//g);
        const NO_ILLEGAL_CHAR = ! /[\s'"\\]/.test(str + '')
        return ((Array.isArray(matches) && matches.length > 0) && NO_ILLEGAL_CHAR ||
            ((Array.isArray(matches) && (str + '').includes('.')))) && NO_ILLEGAL_CHAR;
    }

    const looksLikeCss = (str) => {
        const regExp = /[a-z0-9-_:\s]+location|location[\s:_]+[a-z0-9-_:\s]+/;
        return regExp.test(str + '');
    }

    const addStrToList = function (str, stringsList) {
        if (!stringsList.toString().includes(str)) {
            stringsList.push(str);
        }
    }

    const containsSkippedStr = function (codeSnippet, stringsList) {
        for (let i = 0; i < stringsList.length; i++) {
            const curStr = stringsList[i];
            if ((codeSnippet + '').includes(curStr)) {
                return true;
            }
        }

        return false;
    }

    const isSubstringOfSnippet = function (targetedSnippet, stringsList) {
        for (let i = 0; i < stringsList.length; i++) {
            const curStr = stringsList[i];
            if (((targetedSnippet + '').includes(curStr) &&
                (targetedSnippet + '').replace(curStr, '').length > 0) ||
                ((curStr + '').includes(targetedSnippet) &&
                    (curStr + '').replace(targetedSnippet, '').length > 0)) {
                return true;
            }
        }

        return false;
    }

    const replaceLocationInSnippet = function (jsCode, newJsCode, node) {
        const replaced = jsCode.substring(node.start, node.end);
        const matches = replaced.matchAll(new RegExp(thisHelper.LOCATION_STR, 'mg'));
        const matchesAsArray = Array.from(matches);

        if (matchesAsArray.length === 0 || containsSkippedStr(replaced, skippedStrings))
            return newJsCode;

        if (matchesAsArray.length === 1) {
            const replacement = replaced.replace(new RegExp(thisHelper.LOCATION_STR, 'mg'), thisHelper.MCOP_LOCATION_STR);
            return newJsCode.replace(replaced, replacement);
        } else {
            let progressiveReplaced = replaced.substring(0, matchesAsArray[1].index) + thisHelper.MCOP_LOCATION_STR;
            const replacement = progressiveReplaced.replace(thisHelper.LOCATION_STR, thisHelper.MCOP_LOCATION_STR);
            return newJsCode.replace(progressiveReplaced, replacement);
        }
    }

    const canLocationBeReplacedInMemberExpression = function (node, jsCode) {
        const snippet = jsCode.substring(node.start, node.end);
        const match = Array.from(snippet.matchAll(new RegExp(thisHelper.LOCATION_STR, 'g')))[0];
        const start = node.start; //the index of the char before l
        const end = match.index + thisHelper.LOCATION_STR.length - 1; // the index of the char after n
        const charBeforeFirstLetter = jsCode.charAt(start - 1);
        const charAfterLastLetter = snippet.charAt(end + 1);
        const test1 =
            start === 0 || ALLOWED_CHARS_REGEXP.test(charBeforeFirstLetter);
        const test2 =
            charAfterLastLetter.length === 0 || ALLOWED_CHARS_REGEXP.test(charAfterLastLetter);

        return (test1 && test2);
    }

    const canLocationBeReplacedInProperty = function (node, jsCode) {
        let snippet = jsCode.substring(node.start, node.end);

        const match = Array.from(snippet.matchAll(new RegExp(thisHelper.LOCATION_STR, 'g')))[0];
        const charBefore = jsCode.charAt(node.start - 1);
        const lastCharIndex = match.index + thisHelper.LOCATION_STR.length;
        const charAfter = snippet.charAt(lastCharIndex);
        const test1 = charBefore.length === 0 || ALLOWED_CHARS_REGEXP.test(charBefore);
        const test2 = charAfter.length === 0 || ALLOWED_CHARS_REGEXP.test(charAfter);

        if (node.type === 'Literal') {
            return snippet
                .replace(/['"]/g, '')
                .replace(thisHelper.LOCATION_STR, '').length === 0;
        }

        return test1 && test2;
    }

    const locationIsPartOfIdentifier = function (memberExprNode, jsCode) {
        const snippet = jsCode.substring(memberExprNode.start, memberExprNode.end);
        const match = Array.from(snippet.matchAll(new RegExp(thisHelper.LOCATION_STR, 'g')))[0];
        const start = match.index;
        const charBeforeL = (start > 0) ? snippet.charAt(start - 1) : '';
        return (charBeforeL.length > 0 && !ALLOWED_CHARS_REGEXP.test(charBeforeL));
    }

    try {
        let jsCodeTree = parseJsCode(jsCode);
        let newJsCode = jsCode;
        // console.time("Traversing");
        acornTreeWalk.full(jsCodeTree, function (node) {
            if (node.type === "Program")
                return;

            const nodeSnippet = jsCode.substring(node.start, node.end);

            if (node.type === 'Literal' && node.raw && node.raw.includes(thisHelper.LOCATION_STR)) {
                if (looksLikeURL(node.raw) || looksLikeCss(node.raw)) {
                    addStrToList(node.raw, skippedStrings);
                    return;
                }
                //No need to replace Literal : break key matches with the json data in Ahrefs.com
                //groupedNodes.literal.push(node);
            } else if (node.type === 'MemberExpression' &&
                nodeSnippet.includes(thisHelper.LOCATION_STR) &&
                node.object && node.property) {
                const objectPartSnippet = jsCode.substring(node.object.start, node.object.end);
                const propertyPartSnippet = jsCode.substring(node.property.start, node.property.end);

                const type1 = (typeof node.object === 'object' &&
                    !objectPartSnippet.includes(thisHelper.LOCATION_STR) &&
                    typeof node.property === 'object' &&
                    propertyPartSnippet.includes(thisHelper.LOCATION_STR));

                const type2 = (typeof node.object === 'object' &&
                    objectPartSnippet.includes(thisHelper.LOCATION_STR) &&
                    typeof node.property === 'object' &&
                    !propertyPartSnippet.includes(thisHelper.LOCATION_STR));

                if (!(type1 || type2)) {
                    return;
                }

                //we check the characters before the l and after the n of "location" to check if it can be
                // replaced by __mcopLocation
                if (!canLocationBeReplacedInMemberExpression(node, jsCode)) {
                    return;
                }

                groupedNodes.memberExpr.push(node);
            } else if (node.type === 'Identifier' && typeof node.name === 'string' &&
                (node.name + '').includes(thisHelper.LOCATION_STR)) {
                const snippet = jsCode.substring(node.start, node.end);
                const remaining = snippet.replace(thisHelper.LOCATION_STR, '');
                if (remaining.length > 0) {
                    addStrToList(snippet, skippedStrings);
                    return;
                }

                //console.log(snippet);
                groupedNodes.identifier.push(node);
            } else if (node.type === 'Property' && nodeSnippet.includes(thisHelper.LOCATION_STR)) {
                groupedNodes.property.push(node);
            } else if (node.type === 'ObjectPattern' &&
                jsCode.substring(node.start, node.end).includes(thisHelper.LOCATION_STR)
                && Array.isArray(node.properties)) {
                for (let i = 0; i < node.properties.length; i++) {
                    const curPropNode = node.properties[i];
                    const propSnippet = jsCode.substring(curPropNode.start, curPropNode.end);
                    if (!propSnippet.includes(thisHelper.LOCATION_STR))
                        continue;
                    groupedNodes.objectPattern.push(curPropNode);
                }
            }
        });
        // console.timeEnd("Traversing");
        // console.time("Concatenating");
        groupedNodes.allOrdered =
            groupedNodes.literal.concat(groupedNodes.memberExpr,
                groupedNodes.objectPattern, groupedNodes.property, groupedNodes.identifier);
        // console.timeEnd("Concatenating");

        // console.time("Another Contcatenation")
        groupedNodes.allOrdered.forEach(function (node) {
            if (node.type === 'Literal') {
                const originalSnippet = jsCode.substring(node.start, node.end);
                const modifiedSnippet =
                    originalSnippet.replace(new RegExp(thisHelper.LOCATION_STR, 'mg'),
                        thisHelper.MCOP_LOCATION_STR);
                newJsCode = newJsCode.replace(originalSnippet, modifiedSnippet);
            } else if (node.type === 'MemberExpression') {
                const originalSnippet = jsCode.substring(node.start, node.end);

                if (locationIsPartOfIdentifier(node, jsCode)) {
                    processedMemberNodesDetails.push({
                        originalSnippet: originalSnippet,
                        modifiedSnippet: originalSnippet,
                    });
                    return;
                }

                //We copy before modification
                const newJsCodeCopy = newJsCode;
                findAllOccurrences(originalSnippet, newJsCode).forEach(function (curOccurrence) {
                    const start = curOccurrence.index;
                    const end = start + originalSnippet.length - 1;
                    const charBeforeFirstOne = newJsCodeCopy.substring(start - 1, start);
                    const charAfterLastOne = newJsCodeCopy.substring(end + 1, end + 2);
                    const charBeforeIsFine = start === 0 || ALLOWED_CHARS_REGEXP.test(charBeforeFirstOne);
                    const charAfterIsFine = charAfterLastOne.length === 0 || ALLOWED_CHARS_REGEXP.test(charAfterLastOne);

                    if (charBeforeIsFine && charAfterIsFine) {
                        let replaced = originalSnippet;
                        if (charBeforeFirstOne) {
                            replaced = charBeforeFirstOne + replaced;
                        }

                        if (charAfterLastOne) {
                            replaced = replaced + charAfterLastOne;
                        }

                        const modifiedSnippet =
                            originalSnippet.replace(thisHelper.LOCATION_STR, thisHelper.MCOP_LOCATION_STR);
                        const replacement = charBeforeFirstOne + modifiedSnippet + charAfterLastOne;
                        processedMemberNodesDetails.push({
                            originalSnippet: replaced,
                            modifiedSnippet: replacement,
                        });

                        newJsCode = newJsCode.replace(replaced, replacement);
                    }
                });
            } else if (node.type === 'ObjectPattern') {
                newJsCode = replaceLocationInSnippet(jsCode, newJsCode, node);
            } else if (node.type === 'Property') {
                const charBefore = jsCode.substring(node.start - 1, node.start);
                const charAfter = jsCode.substring(node.end, node.end + 1);
                let originalSnippet = charBefore + jsCode.substring(node.start, node.end) + charAfter;

                //We skip any snippet that was already processed and is a substring of the current snippet
                if (isSubstringOfSnippet(originalSnippet, processedPropertyNodeSnippets)) {
                    //console.log(originalSnippet)
                    return;
                }

                const valuePartContainsProcessedMemberExp = function (valueNode) {
                    const valueOriginalSnippet = jsCode.substring(valueNode.start, valueNode.end);
                    let result = false;
                    processedMemberNodesDetails.forEach(function (details) {
                        const memberExprOriginalSnippet = details.originalSnippet + '';
                        if (memberExprOriginalSnippet.includes(valueOriginalSnippet) ||
                            valueOriginalSnippet.includes(memberExprOriginalSnippet)) {
                            result = true;
                        }
                    });

                    return result;
                }

                const replaceLocationInPart = function (node) {
                    if (looksLikeURL(jsCode.substring(node.start, node.end))) {
                        return;
                    }

                    const charBefore = jsCode.charAt(node.start - 1);
                    const charAfter = jsCode.charAt(node.end);
                    const originalSnippet = charBefore + jsCode.substring(node.start, node.end) + charAfter;
                    const modifiedSnippet =
                        originalSnippet.replace(thisHelper.LOCATION_STR, thisHelper.MCOP_LOCATION_STR);
                    const test1 = charBefore === '' || ALLOWED_CHARS_REGEXP.test(charBefore);
                    const test2 = charAfter === '' || ALLOWED_CHARS_REGEXP.test(charAfter);

                    if (test1 && test2) {
                        while (newJsCode.indexOf(originalSnippet) !== -1) {
                            newJsCode = newJsCode.replace(originalSnippet, modifiedSnippet);
                        }
                    }
                }

                if (typeof node.key === 'object' &&
                    generateCodeFromTree(node.key).includes(thisHelper.LOCATION_STR) &&
                    canLocationBeReplacedInProperty(node.key, jsCode)) {
                    const keyPart = jsCode.substring(node.key.start, node.key.end);
                    const remaining = keyPart.replace(thisHelper.LOCATION_STR, '')
                        .replace(/"/g, '').replace(/'/g, '');

                    if (!looksLikeURL(keyPart) && remaining.length === 0) {
                        replaceLocationInPart(node.key);
                    }
                }

                if (typeof node.value === 'object' &&
                    generateCodeFromTree(node.value).includes(thisHelper.LOCATION_STR) &&
                    canLocationBeReplacedInProperty(node.value, jsCode) &&
                    !valuePartContainsProcessedMemberExp(node.value)) {
                    if (node.value.type !== 'FunctionExpression') {
                        replaceLocationInPart(node.value);
                    }
                }

                processedPropertyNodeSnippets.push(originalSnippet);
            } else if (node.type === 'Identifier') {
                const charBefore = jsCode.substring(node.start - 1, node.start);
                const charAfter = jsCode.substring(node.end, node.end + 1);
                const test1 = charBefore.length === 0 || ALLOWED_CHARS_REGEXP.test(charBefore);
                const test2 = charAfter.length === 0 || ALLOWED_CHARS_REGEXP.test(charAfter);
                if (test1 && test2) {
                    const originalSnippet = charBefore + jsCode.substring(node.start, node.end) + charAfter;
                    const modifiedSnippetSnippet =
                        originalSnippet.replace(thisHelper.LOCATION_STR, thisHelper.MCOP_LOCATION_STR);
                    newJsCode = newJsCode.replace(originalSnippet, modifiedSnippetSnippet);
                }
            }
        });
        // console.timeEnd("Another Contcatenation")
        //console.log(skippedStrings)
        return newJsCode;
    } catch (error) {
        throw error;
    }
};

const parseJsCode = function (jsCode, options = { ecmaVersion: "latest" }) {

    // if (/(import|export)\s*\(/.test(jsCode + '')) {
    if (/\b(import|export)\s*(?:\{[\s\S]*?\}|\*\s*as\s*\w+|\w+)(?:\s*from\s*(['"].+?['"]|`[^`]+`))?\s*;?/.test(jsCode + '') || /(import|export)\s*\(/.test(jsCode + '')) {
        options.sourceType = 'module';
        // console.log('SourceType: ' + options.sourceType)
    }

    try {
        // console.time("AcornParse");
        let ret = acorn.parse(jsCode, options)
        // console.timeEnd("AcornParse");
        return ret;
    } catch (e) {
        console.log(e);
        return acornLoose.parse(jsCode, options);
    }
};

// This function is optional as its most time-costful function is parseJsCode
const replacePostMessage = function (jsCode) {
    //The code is likely a JSON object.
    /*if (/^{/m.test(jsCode) &&  /}$/m.test(jsCode))
        return jsCode;*/

    if (typeof jsCode !== 'string')
        throw new Error('Invalid JavaScript code');

    if (! /postMessage/mg.test(jsCode))
        return jsCode;


    const MCOP_FUNC1_NAME = '_mcopPreparePostMessageMsg';
    const MCOP_FUNC2_NAME = '_mcopPreparePostMessageOrigin';
    const POST_MESSAGE_NAME = 'postMessage';

    const removeNewlines = function (str) {
        if (typeof str !== 'string' || /void\s+/.test(str)) return str;
        return str.replace(/[\n\s]/g, '');
    }

    //
    const buildArgumentsPart = function (args) {
        if (!Array.isArray(args) || !(args.length >= 1 && args.length <= 3))
            return '';

        if (args.length === 1) {
            const arg1Part = removeNewlines(jsCode.substring(args[0].start, args[0].end));
            if (args[0].type === 'SequenceExpression') {
                return `${MCOP_FUNC1_NAME}((${arg1Part}))`;
            } else {
                return `${MCOP_FUNC1_NAME}(${arg1Part})`;
            }
        } else if (args.length === 2) {
            let argumentsPart = buildArgumentsPart([args[0]]);
            const arg2Part = removeNewlines(jsCode.substring(args[1].start, args[1].end));
            if (args[1].type === 'SequenceExpression') {
                argumentsPart += `,${MCOP_FUNC2_NAME}((${arg2Part}))`;
            } else {
                argumentsPart += `,${MCOP_FUNC2_NAME}(${arg2Part})`;
            }
            return argumentsPart;
        } else if (args.length === 3) {
            let argumentsPart = buildArgumentsPart([args[0], args[1]]);
            const arg3Part = removeNewlines(jsCode.substring(args[2].start, args[2].end));
            if (args[2].type === 'SequenceExpression') {
                argumentsPart += `,(${arg3Part})`;
            } else {
                argumentsPart += `,${arg3Part}`;
            }
            return argumentsPart;
        }
    }

    try {

        let jsCodeTree = parseJsCode(jsCode);
        let newJsCode = jsCode;

        acornTreeWalk.full(jsCodeTree, function (node) {
            if (node.type === "Program")
                return;

            if (node.type === 'CallExpression' &&
                node.callee && node.callee.property &&
                generateCodeFromTree(node.callee.property).includes(POST_MESSAGE_NAME) &&
                Array.isArray(node.arguments) && node.arguments.length > 0) {
                const originalSnippet = jsCode.substring(node.start, node.end);

                if (node.arguments.length >= 1 && node.arguments.length <= 3) {
                    const callPart = originalSnippet.split(POST_MESSAGE_NAME)[0] + POST_MESSAGE_NAME;
                    let modifiedSnippet = `${callPart}(${buildArgumentsPart(node.arguments)})`;
                    newJsCode = newJsCode.replace(originalSnippet, modifiedSnippet);
                }
            }
        });

        return newJsCode;
    } catch (error) {
        throw error;
    }
};

try {
    const inputFilePath = path.join(__dirname, 'HandlerHelpers.test.js');
    const outputFilePath = path.join(__dirname, 'output.txt');

    // Read the file synchronously
    let body = fs.readFileSync(inputFilePath, 'utf8');
  
    console.time("OriginalEngine");
    // Perform the string replacement
    body = replaceLocationInJsCode(body);
    body = replacePostMessage(body); 
    console.timeEnd("OriginalEngine");
    // // Write the modified content to a new file
    
    fs.writeFileSync(outputFilePath, body, 'utf8');
    console.log('File has been saved successfully.');
  } catch (err) {
    console.error('Error:', err);
  }